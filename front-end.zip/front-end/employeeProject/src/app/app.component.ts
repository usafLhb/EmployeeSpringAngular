import { HttpErrorResponse } from '@angular/common/http';
import { SelectorMatcher } from '@angular/compiler';
import { Container } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './employee.service';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 public employees!:Employee[] ;
 public updateEmployee:Employee| undefined;
 public EmployeeDelete!:Employee;
 
 constructor (private employeeServive:EmployeeService){}
  ngOnInit() {
    this.getEmloyees();
  }
 public getEmloyees():void{
  this.employeeServive.getEmployees().subscribe(
    (response:Employee[])=>{
      this.employees=response;
    },
    (error:HttpErrorResponse)=>{
      alert(error.message);
    }
  );
 }

 public onOpenModal(employee:Employee,mode:string):void{
 
  const button =document.createElement('button');
  const container =document.getElementById('main-container'); 
  button.type='button';
  button.style.display='none';
  button.setAttribute('data-toggle','modal');
  if(mode==='add'){
    button.setAttribute('data-target','#addEmployeeModal');
  }
  if(mode==='update'){
    this.updateEmployee=employee;
    button.setAttribute('data-target','#updateEmployeeModal');
  }
  if(mode==='delete'){
    
    this.EmployeeDelete=employee;
    button.setAttribute('data-target','#deleteEmployeeModal');
  }
   container?.appendChild(button);
  button.click();
 
 }

 public onAddEmployee(addForm : NgForm):void{
  document.getElementById('addEmployeeClose')?.click;
  this.employeeServive.addEmployee(addForm.value).subscribe(
    (response:Employee)=>{
      console.log(response);
      addForm.reset();
      this.getEmloyees();
    },
    (error:HttpErrorResponse)=>{
      alert(error.message);
    }
  );
 }


 public onUpdateEmployee(employee : Employee):void{
  document.getElementById('updateEmployeeClose')?.click;
  console.log(employee);
  this.employeeServive.updateEmployee(employee).subscribe(
    (response:Employee)=>{
      console.log(response);
      this.getEmloyees();
    },
    (error:HttpErrorResponse)=>{
      alert(error.message);
    }
  );
 }


 public onDeleteEmployee(idEmployee : Employee):void{
  document.getElementById('deleteEmployeeModal')?.click; 
  this.employeeServive.deleteEmployee(idEmployee.id).subscribe(
    (response:void)=>{
      console.log(response);
      this.getEmloyees();
    },
    (error:HttpErrorResponse)=>{
      alert(error.message);
    }
  );
 }

 public searchEmployee(key:string):void{
  const rslt:Employee[]=[];
  for(const employee of this.employees){
    if(employee.name.toLowerCase().indexOf(key.toLowerCase())!==-1){
      rslt.push(employee);
    }
  }
  this.employees=rslt;
  if(rslt.length===0 || !key){
    this.getEmloyees();
  }
 }

}
